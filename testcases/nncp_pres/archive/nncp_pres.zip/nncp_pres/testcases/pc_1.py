a = h(f(), g())

