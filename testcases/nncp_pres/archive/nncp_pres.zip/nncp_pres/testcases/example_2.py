a=[1,3]
x=1
c=3
b=[5,9,5,3,8]
y=2
c= b + a
z=c - a
d = c[:, b]
e = list((a, b, c))

