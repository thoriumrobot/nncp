# Dictionary 
dict = { 
    'stu': 1,
    'lvl': 2,
    'yr' : 2020,
    'name': 'joe'
}
i = dict + {'stat': True}

w=dict('yr')
