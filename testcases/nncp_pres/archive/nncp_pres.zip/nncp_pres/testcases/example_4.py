# simple Dictionary 
dict = { 'id': 1, 'od': 2 }
