x=1
c=3
y=2
c=h(f(),g())